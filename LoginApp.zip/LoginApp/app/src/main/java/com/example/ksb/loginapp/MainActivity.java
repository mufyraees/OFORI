package com.example.ksb.loginapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import android.graphics.Color;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    private EditText username;
    private EditText password;
    private Button login;
    private TextView loginLockedTV;
    private TextView attemptsLeftTV;
    private boolean isLoggedIn = false;
    private TextView numberOfRemainingLoginAttemptsTV;
    int numberOfRemainingLoginAttempts = 3;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setupVariables();
        login.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                //authenticate user on login click
                isValidUser(view,username.getText().toString(),password.getText().toString());
            }
        });
    }


    private void setupVariables() {
        username = (EditText) findViewById(R.id.usernameET);
        password = (EditText) findViewById(R.id.passwordET);
        login = (Button) findViewById(R.id.loginBtn);
        loginLockedTV = (TextView) findViewById(R.id.loginLockedTV);
        attemptsLeftTV = (TextView) findViewById(R.id.attemptsLeftTV);
        numberOfRemainingLoginAttemptsTV = (TextView) findViewById(R.id.numberOfRemainingLoginAttemptsTV);
        numberOfRemainingLoginAttemptsTV.setText(Integer.toString(numberOfRemainingLoginAttempts));
    }

    public void moveToLoggedPage(View view){
        Intent i = new Intent(view.getContext(),LoggedInView.class);
        startActivity(i);
    }
    public void isValidUser(final View view,final String username,final String password){

            RequestQueue queue = Volley.newRequestQueue(this);
            String loginUrl = "http://192.168.1.3/loginAndroid.php";

        StringRequest stringRequest = new StringRequest(Request.Method.POST, loginUrl,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            try{
                                response = response.replace("\r\n","");
                                JSONObject object = new JSONObject(response);
                                boolean success = object.getBoolean("success");
                                if(success){
                                    moveToLoggedPage(view);
                                }else{
                                   showErrorMessage(object.getString("message"));
                                }

                            }catch (Exception e){
                                e.printStackTrace();
                                showErrorMessage("Unknown Error");
                            }

                        }
                    }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        showErrorMessage(error.getMessage());
                    }
            }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("uname", username);
                params.put("psw", password);
                return params;
            }
        };
        queue.add(stringRequest);

    }
    private void showErrorMessage(String message){
        //otherwise show a error text;
        Toast.makeText(getApplicationContext(), message,
                Toast.LENGTH_SHORT).show();
        numberOfRemainingLoginAttempts--;
        attemptsLeftTV.setVisibility(View.VISIBLE);
        numberOfRemainingLoginAttemptsTV.setVisibility(View.VISIBLE);
        numberOfRemainingLoginAttemptsTV.setText(Integer.toString(numberOfRemainingLoginAttempts));

        if (numberOfRemainingLoginAttempts == 0) {
            login.setEnabled(false);
            loginLockedTV.setVisibility(View.VISIBLE);
            loginLockedTV.setBackgroundColor(Color.RED);
            loginLockedTV.setText("LOGIN LOCKED!!!");
        }
    }
}
