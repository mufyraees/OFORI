package com.example.ksb.loginapp;

import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class LoggedInView extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_logged_in_view);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        //create a webview inside the layout to show the web page
        WebView myWebView = (WebView) findViewById(R.id.webview);
        //set webview client to use a browser inside the app
        myWebView.setWebViewClient(new WebViewClient());
        //load the page url into the view
        myWebView.loadUrl("http://192.168.1.3/adminhome1.html");
    }

}
